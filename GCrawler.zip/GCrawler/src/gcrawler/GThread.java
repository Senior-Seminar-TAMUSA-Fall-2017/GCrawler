/*
 * GThread.java
 * Created by Arlen McDonald 9/3/17
 * 
 * This program is a helper class for GCrawler.
 */
package gcrawler;

import java.io.BufferedInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.PipedOutputStream;

public class GThread implements Runnable{
    
    // Variable Declarations
    private String URL;
    private Integer port;
    private Integer depth = 0;  // How many links deep you have travelled.
    private Integer maxDepth = 30;  // Limit crawling depth.
    
    // Create reference to output pipe
    private PipedOutputStream outPipe;
    
    // Create command Queue
    ArrayList<String> comQueue = new ArrayList();
    
    public GThread(String URLIn, Integer portIn, PipedOutputStream pOutput){  // Constructor for GThread
        URL = URLIn;
        port = portIn;
        outPipe = pOutput;
    }

    @Override
    public void run(){  // Everything you want the thread to do has to start here.
        
        comQueue.add("\r\n");  // Root command - Display main menu - Will run once per site.
        
        try{  // For network actions
            
            // Loop while there are commands in the queue and not at max.
            while(comQueue.size() > depth && depth < maxDepth){
                
                // Create a socket - This is connection oriented, disconnects when all its data is delivered.
                Socket gopher = new Socket(URL, port);
                
                // Create a scanner for the input stream from the server
                Scanner inPut = new Scanner(new BufferedInputStream(gopher.getInputStream()));

                // Create an output stream to send data to the server
                DataOutputStream outPut = new DataOutputStream(gopher.getOutputStream());

                // Show the user what is happening 
                if(comQueue.get(depth) == "\r\n") System.out.println("Crawling Site: " + URL);
                else System.out.print("\tCrawling Link: " + URL + " " + comQueue.get(depth));
                
                // Send data out
                outPut.writeBytes(comQueue.get(depth));

                // Get data back from site and send it to the pipe.
                while(inPut.hasNextLine()){
                    try{
                        outPipe.write(ParseMenu(inPut.nextLine().replace("%", "").replace("\"", "")).getBytes());
                    }
                    catch(Exception ex){
                        System.out.println(ex.toString());
                    }
                }
                depth++;
            }
            // Finishing up
            System.out.println("Exiting Site: " + URL);
        }
        catch (Exception ex){  // I know I need to break this down a lot more, but for now...
            System.out.println(ex.toString());
        }
    }
    
    // A method to parse the data returned from the gopher into csv format so it can be saved in a file.
    private String ParseMenu(String str){
        
        // Variable declarations
        String header = "\"" + URL + "\",\"" + port + "\",\"" + comQueue.get(depth).replace("\r\n","") + "\",\"";
        String text1; // Generic variables to hold strings.
        String text2;
        String text3;
        String text4;
        
          // Instance scanner object, tab delimited
        Scanner token = new Scanner(str).useDelimiter("\t");
        
        if(str.equals(".")) return  ""; // Check for Full Stop - end of data

        else{  // Select different cannonical data types.

            if(str.contains("\t")){  // valid menu items always contain tabs.

                // Text file
                if(str.startsWith("0")){
                    return "\"0\"," + header +  token.next().substring(1) + "\",\"" + token.next() + "\"%";
                }

                // Submenu (Gopher)
                else if(str.startsWith("1")){
                    text1 = token.next().substring(1);
                    text2 = token.next();
                    text3 = token.next();
                    text4 = token.next();
                    if(text2.startsWith("/")){  // Check if it is a valid command.
                        // Grab link and add it to the command queue, only if it is not already there, prevents loops.
                        if(!comQueue.contains(text2 + "\r\n") && URL.contentEquals(text3)){
                            comQueue.add(text2 + "\r\n");
                            return "\"1\"," + header  + text1 + "\",\"" + text2 + "\"%";
                        }
                        // Not a local link send the URL back to the master.
                        else if(!URL.contentEquals(text3)){
                            return "\"~" + text3.toLowerCase() + "%";  
                        }
                    }
                    return "";  // Do not log if not local
                }

                // CCSO nameserver
                else if(str.startsWith("2")){
                    return "\"2\"," + header + token.next().substring(1) + "\",\"" + token.next()+ "\"%";
                }

                // Error response from server
                else if(str.startsWith("3")){
                    return "\"3\"," + header + token.next().substring(1)+ "\"%";
                }

                // BinHex file (Old Mac stuff)
                else if(str.startsWith("4")){
                    return "\"4\"," + header + token.next().substring(1) + "\",\"" + token.next()+ "\"%";
                }

                // DOS format file
                else if(str.startsWith("5")){
                    return "\"5\"," + header + token.next().substring(1) + "\",\"" + token.next()+ "\"%";
                }

                // UUEncoded file
                else if(str.startsWith("6")){
                    return "\"6\"," + header + token.next().substring(1) + "\",\"" + token.next()+ "\"%";
                }

                // Search engine (Archie?)
                else if(str.startsWith("7")){
                    return "\"7\"," + header + token.next().substring(1) + "\",\"" + token.next()+ "\"%";
                }

                // Telnet
                else if(str.startsWith("8")){
                    return "\"8\"," + header + token.next().substring(1) + "\",\"" + token.next()+ "\"%";
                }

                // Binary file
                else if(str.startsWith("9")){
                    return "\"9\"," + header + token.next().substring(1) + "\",\"" + token.next()+ "\"%";
                }

                // Mirrored Server
                else if(str.startsWith("+")){
                    return "\"+\"," + header + token.next().substring(1) + "\",\"" + token.next()+ "\"%";
                }

                // GIF file
                else if(str.startsWith("g")){
                    return "\"g\"," + header + token.next().substring(1) + "\",\"" + token.next()+ "\"%";
                }

                // Image file
                else if(str.startsWith("I")){
                    return "\"I\"," + header + token.next().substring(1) + "\",\"" + token.next()+ "\"%";
                }

                // Telnet 3270 (Old IBM stuff)
                else if(str.startsWith("T")){
                    return "\"T\"," + header + token.next().substring(1) + "\",\"" + token.next()+ "\"%";
                }

                // Non-cannonical types - Not in the spec but recognized everywhere.

                // HTML
                else if(str.startsWith("h")){
                    return "\"h\"," + header + token.next().substring(1) + "\",\"" + token.next()+ "\"%";
                }

                // Informational Message
                else if(str.startsWith("i")){
                    return "\"i\"," + header + token.next().substring(1,str.indexOf("\t")) + "\"%";
                }

                // Sound file
                else if(str.startsWith("s")){
                    return "\"s\"," + header + token.next().substring(1) + "\",\"" + token.next()+ "\"%";
                }
            }
        }
        return "";  // Only malformed packets should get here, discard them.
    }
}
