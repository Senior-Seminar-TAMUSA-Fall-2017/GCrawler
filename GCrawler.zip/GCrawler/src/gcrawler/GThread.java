/*
 * GThread.java
 * Created by Arlen McDonald 9/3/17
 * 
 * This program is a helper class for GCrawler.
 */
package gcrawler;

import java.io.BufferedInputStream;
import java.io.DataOutputStream;
import java.io.FileWriter;
import java.net.Socket;
import java.util.Scanner;

public class GThread implements Runnable{
    
    // Variable Declarations
    String curURL;
    Integer curPort;
    String command = "\r\n";  // Default command string - Display the menu.
    
    public GThread(String URL, Integer port){  // Constructor for GThread
        curURL = URL;
        curPort = port;
    }

    @Override
    public void run(){
        
        System.out.println("Crawling to " + curURL);  // Got this far
        
        try{  // For both network and file actions, for now.
            
            // Create a file
            FileWriter wr = new FileWriter(curURL.replace(".","")+".txt");

            // Create a socket
            Socket gopher = new Socket(curURL, curPort);

            // Create an scanner for the input stream from the server
            Scanner inPut = new Scanner(new BufferedInputStream(gopher.getInputStream()));

            // Create an output stream to send data to the server
            DataOutputStream outPut = new DataOutputStream(gopher.getOutputStream());

            // Send data out
            outPut.writeBytes(command + "\r\n");

            // Get data back
            while(inPut.hasNextLine()){
                wr.append(inPut.nextLine()+"\n");  // For now just dumping everything into a file.
                // Need code to pull out URLs and send them back to the main.
            }
            
            // Done with the file
            wr.close();  
            
            System.out.println("Exiting " + curURL);  // Finishing up
        }
        catch (Exception ex){  // I know I need to break this down a lot more, but for now...
            System.out.println(ex.toString());
        }
    }
}
