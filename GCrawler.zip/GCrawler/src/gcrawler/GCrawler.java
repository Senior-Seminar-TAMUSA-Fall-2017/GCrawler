/*************************************
 * GCrawler.java
 *
 * This is a small proof-of-concept
 * program for creating a client that will crawl
 * through Gopher space.
 * VERY limited at this time, need to pull URLs
 * from the crawled sites and send them back to
 * the main via a pipe and add them to the queue.
 * 
 * Output is in files, filename is the URL with 
 * the periods removed plus .txt
 * 
 * 
 * URLs to try "gopher.floodgap.com"
 *             "pollett.org"
 *             "gopher.superglobalmegacorp.com"
 * 
 * For information about Gopher;
 * https://en.wikipedia.org/wiki/Gopher_(protocol)
 *
 * Author - Arlen McDonald
 * Created - 9/3/17
 *
 ************************************/
package gcrawler;

import java.util.ArrayList;

public class GCrawler {

    public static void main(String[] args) {
        
        // Variable declarations
        Integer port = 70;  // Default port - Need to create a nice URL object that contains the port.
        
        // Create an ArrayList for URLs and load it with some initial data.
        // Still need figure out how to get data back from the threads
        // and put it into the queue.
        ArrayList<String> URLQueue = new ArrayList();
        URLQueue.add("gopher.floodgap.com");
        URLQueue.add("gopher.superglobalmegacorp.com");
        URLQueue.add("pollett.org");

        // Main loop
        while(!URLQueue.isEmpty()){ // Loop while there are URLs in the queue.
            
                // Create a thread for each URL.
                Thread thd = new Thread(new GThread(URLQueue.remove(0), port));
                thd.start();  // This evidently calls the run method automatically.

        }
    }
}
