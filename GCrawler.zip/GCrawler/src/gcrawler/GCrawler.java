/*************************************
 * GCrawler.java
 *
 * This program is a client used to
 * crawl through Gopher space.
 * 
 * Each site spawns its own thread, but I do not
 * spawn more than one thread per site for fear of
 * causing some sort of denial of service.
 * 
 * Found URLs are sent to the main and spawned
 * as a new thread provided they are have not already
 * been queued.
 * 
 * Links that are internal to a site are
 * queued and crawled.  Duplicate links are checked
 * for and rejected so that loops are not created.
 * 
 * Output is in files, filename is, output + packet type + .csv
 * Format is packet type, URL, port, and content.
 * 
 * For information about Gopher;
 * https://en.wikipedia.org/wiki/Gopher_(protocol)
 *
 * Author - Arlen McDonald
 * Created - 9/3/17
 * Modified - 9/7/17 - Formatted output files
 * Modified - 9/16/17 - Created pipe to send thread data back to master.
 * Modified - 9/23/17 - Created master output files by type.
 *
 ************************************/
package gcrawler;

import java.io.FileWriter;
import java.io.BufferedWriter;
import java.util.ArrayList;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.util.Scanner;

public class GCrawler {

    public static void main(String[] args) {
        
        // Variable declarations
        Integer port = 70;  // Default port - Need to create a nice URL object that contains the port.
        String token;  // Input from remote pipes.
        Integer depth = 0;
        
        // Create an ArrayList for URLs and load it with some initial data.
        // Still need figure out how to get data back from the threads
        // and put it into the queue.
        ArrayList<String> URLQueue = new ArrayList();
        //URLQueue.add("gopher.floodgap.com");
        //URLQueue.add("gopher.superglobalmegacorp.com");
        //URLQueue.add("sdf.org");
        URLQueue.add("i-logout.cz");
        URLQueue.add("hngopher.com");
        URLQueue.add("gopherpedia.com");
        //URLQueue.add("grex.org");
        URLQueue.add("tomatobodhi.twilightparadox.com");
        URLQueue.add("gopher.metafilter.com");
        
        // Create pipes for input and output and connect them
        PipedInputStream pInput = new PipedInputStream();
        PipedOutputStream pOutput = new PipedOutputStream();
        try{
            pInput.connect(pOutput);  // Connect the ends
        }
        catch(Exception ex){
            System.out.println(ex.toString());
        }
        
        // Main loop
        try{
            // Create a scanner object, % delimited.
            Scanner inPipe = new Scanner(pInput).useDelimiter("%");
            
            // Create output files
            BufferedWriter wr0 = new BufferedWriter(new FileWriter("output0.csv")); // Text files
            BufferedWriter wr1 = new BufferedWriter(new FileWriter("output1.csv")); // Submenu
            BufferedWriter wr2 = new BufferedWriter(new FileWriter("output2.csv")); // CCSO Nameserver
            BufferedWriter wr3 = new BufferedWriter(new FileWriter("output3.csv")); // Error response from server
            BufferedWriter wr4 = new BufferedWriter(new FileWriter("output4.csv")); // BinHex files
            BufferedWriter wr5 = new BufferedWriter(new FileWriter("output5.csv")); // DOS files
            BufferedWriter wr6 = new BufferedWriter(new FileWriter("output6.csv")); // UUEncode files
            BufferedWriter wr7 = new BufferedWriter(new FileWriter("output7.csv")); // Search Engine
            BufferedWriter wr8 = new BufferedWriter(new FileWriter("output8.csv")); // Telnet
            BufferedWriter wr9 = new BufferedWriter(new FileWriter("output9.csv")); // Binary files
            BufferedWriter wrg = new BufferedWriter(new FileWriter("outputg.csv")); // GIF files
            BufferedWriter wrh = new BufferedWriter(new FileWriter("outputh.csv")); // HTML Links
            BufferedWriter wri = new BufferedWriter(new FileWriter("outputi.csv")); // Informational message
            BufferedWriter wrImg = new BufferedWriter(new FileWriter("outputImg.csv")); // Image files
            BufferedWriter wrs = new BufferedWriter(new FileWriter("outputs.csv")); // Sound files
            BufferedWriter wrT = new BufferedWriter(new FileWriter("outputT.csv")); // Telnet 3270
            BufferedWriter wrPlus = new BufferedWriter(new FileWriter("outputplus.csv")); // Mirrored servers
            BufferedWriter wrJunk = new BufferedWriter(new FileWriter("outputjunk.csv")); // Malformed packets and unknown.

            // Loop while any of your queues has data.
            while(Thread.activeCount() > 1 || URLQueue.size() > depth || inPipe.hasNext()){
                while(URLQueue.size() > depth){
                    Thread thd = new Thread(new GThread(URLQueue.get(depth), port, pOutput));
                    thd.start();  // This calls the run method automatically.
                    depth++;
                } 
                if(inPipe.hasNext()){  // Pipe contains data.
                    token = inPipe.next();
                    // Save data in appropriate file, or queue it if it is a new URL
                    if(token.startsWith("\"0")) wr0.append(token + "\n").flush();
                    else if(token.startsWith("\"1")) wr1.append(token + "\n").flush();
                    else if(token.startsWith("\"2")) wr2.append(token + "\n").flush();
                    else if(token.startsWith("\"3")) wr3.append(token + "\n").flush();
                    else if(token.startsWith("\"4")) wr4.append(token + "\n").flush();
                    else if(token.startsWith("\"5")) wr5.append(token + "\n").flush();
                    else if(token.startsWith("\"6")) wr6.append(token + "\n").flush();
                    else if(token.startsWith("\"7")) wr7.append(token + "\n").flush();
                    else if(token.startsWith("\"8")) wr8.append(token + "\n").flush();
                    else if(token.startsWith("\"9")) wr9.append(token + "\n").flush();
                    else if(token.startsWith("\"g")) wrg.append(token + "\n").flush();
                    else if(token.startsWith("\"h")) wrh.append(token + "\n").flush();
                    else if(token.startsWith("\"i")) wri.append(token + "\n").flush();
                    else if(token.startsWith("\"I")) wrImg.append(token + "\n").flush();
                    else if(token.startsWith("\"s")) wrs.append(token + "\n").flush();
                    else if(token.startsWith("\"T")) wrT.append(token + "\n").flush();
                    else if(token.startsWith("\"+")) wrPlus.append(token + "\n").flush();
                    else if(token.startsWith("\"~")){  // URLs
                        if(!URLQueue.contains(token.substring(2))) URLQueue.add(token.substring(2)); // Queue only if new.
                    }
                    else wrJunk.append(token + "\n").flush();
                }
                Thread.sleep(10);  // Seems to need at least a little delay, not sure why.
            }
            
            // Done with the files
            wr0.close();
            wr1.close();
            wr2.close();
            wr3.close();
            wr4.close();
            wr5.close();
            wr6.close();
            wr7.close();
            wr8.close();
            wr9.close();
            wrg.close();
            wrh.close();
            wri.close();
            wrImg.close();
            wrs.close();
            wrT.close();
            wrPlus.close();
            wrJunk.close();
            
            // Done with the pipe
            inPipe.close();
        }
        catch(Exception ex){
            System.out.println(ex.toString());
        }
        System.out.println("Crawled "+ depth + " sites.");
    }
}
