/*************************************
 * GCrawler.java
 *
 * This is a small proof-of-concept
 * program for creating a client that will crawl
 * through Gopher space.
 * 
 * Each site spawns its own thread, but I do not
 * spawn more than one thread per site for fear of
 * causing some sort of denial of service.
 * 
 * Still need to pull URLsfrom the crawled sites 
 * and send them back to the main via a pipe and 
 * add them to the queue.
 * 
 * Links that are internal to a site are
 * queued and crawled.  Duplicate links are checked
 * for and rejected so that loops are not created.
 * 
 * Output is in files, filename is the URL with 
 * the periods removed plus .csv
 * Format is URL, port, referring link, packet type, and content.
 * 
 * For information about Gopher;
 * https://en.wikipedia.org/wiki/Gopher_(protocol)
 *
 * Author - Arlen McDonald
 * Created - 9/3/17
 * Modified - 9/7/17 - Formatted output files
 *
 ************************************/
package gcrawler;

import java.util.ArrayList;

public class GCrawler {

    public static void main(String[] args) {
        
        // Variable declarations
        Integer port = 70;  // Default port - Need to create a nice URL object that contains the port.
        
        // Create an ArrayList for URLs and load it with some initial data.
        // Still need figure out how to get data back from the threads
        // and put it into the queue.
        ArrayList<String> URLQueue = new ArrayList();
        URLQueue.add("gopher.floodgap.com");
        URLQueue.add("gopher.superglobalmegacorp.com");
        URLQueue.add("sdf.org");
        URLQueue.add("hngopher.com");
        URLQueue.add("gopherpedia.com");
        URLQueue.add("grex.org");
        URLQueue.add("tomatobodhi.twilightparadox.com");
        URLQueue.add("gopher.metafilter.com");

        // Main loop
        while(!URLQueue.isEmpty()){ // Loop while there are URLs in the queue.
            
            // Create a thread for each URL.
            Thread thd = new Thread(new GThread(URLQueue.remove(0), port));
            thd.start();  // This calls the run method automatically.
        }
    }
}
